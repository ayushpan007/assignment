const mongoose = require("mongoose");
const { Schema } = mongoose;

const patientSchema = new Schema({
  resourceType: {
    type: String,
    required: true,
    default: "Patient",
  },
  name: [
    {
      use: {
        type: String,
        default: "official",
      },
      given: [String],
      family: String,
    },
  ],
  gender: String,
  birthDate: Date,
  telecom: [
    {
      value: String,
      use: String,
      system: String,
    },
  ],
  address: [
    {
      line: [String],
      city: String,
      state: String,
      postalCode: String,
    },
  ],
  patientId: {
    type: String,
    required: true,
    unique: true,
  },
});

const Patient = mongoose.model("Patient", patientSchema);

module.exports = Patient;
