const mongoose = require("mongoose");
const { Schema } = mongoose;

const userSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
    },
    mobileNumber: {
      type: String,
      required: true,
    },
  },
  {
    collection: "Users",
    timestamps: true,
    skipVersioning: true,
    versionKey: false,
  }
);

userSchema.methods.sanitize = function () {
  var User = this;
  User = User.toObject();

  delete User.createdAt;
  delete User.updatedAt;
  delete User.password;

  return User;
};

const User = mongoose.model("Users", userSchema);

module.exports = User;
