const {
  getAllPatients,
  addPatients,
  getPatientById,
  editPatient,
  removePatient,
} = require("../controller/patient");
const { isAuthorized } = require("../middleware/authorized");
module.exports = (router) => {
  //router.get("/getAllPatients", getAllPatients);
  router.post("/patients", isAuthorized, addPatients);
  router.get("/patients/:patientId", isAuthorized, getPatientById);
  router.put("/patients/:patientId", isAuthorized, editPatient);
  router.delete("/patients/:patientId", isAuthorized, removePatient);
};
