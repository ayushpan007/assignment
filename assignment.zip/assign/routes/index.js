const express = require("express");
const router = express.Router();

const pingRoutes = require("./ping");
const userRoute = require("./user");
const patientRoute = require("./patient");
pingRoutes(router);
userRoute(router);
patientRoute(router);

module.exports = router;
