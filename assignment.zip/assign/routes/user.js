const { signup, signin } = require("../controller/user");

module.exports = (router) => {
  router.post("/signup", signup);
  router.post("/signin", signin);
};
