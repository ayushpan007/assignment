import { BrowserRouter, Routes, Route } from 'react-router-dom';

import SignUp from './component/Signup';
import Signin from './component/Signin';
import Home from './component/Home';
import Dashboard from './component/Dashboard';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;