import { useNavigate } from 'react-router-dom';

export default function Home() {

    const navigate = useNavigate();

    return (
        <div className="home">
            <button type="button" class="btn btn-primary" onClick={() => navigate('/signup')}>Sign Up</button>
            <button type="button" class="btn btn-primary" onClick={() => navigate('/signin')}>Sign In</button>
        </div>
    );
}