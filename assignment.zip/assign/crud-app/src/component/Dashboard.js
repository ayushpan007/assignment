import { useState, useEffect } from "react";
import { Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const [patients, setPatients] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editPatient, setEditPatient] = useState(null);

  const token = localStorage.getItem("token");
  const apiUrl = "http://localhost:5000/patients";

  useEffect(() => {
    // Fetch the list of patients when the component mounts
    fetch(apiUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setPatients(data);
      })
      .catch((error) => {
        console.error("Error fetching patient data:", error);
      });
  }, [token]);

  const handleDelete = (patientId) => {
    // Make an API request to delete the patient by their ID
    fetch(`${apiUrl}/${patientId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => {
        if (response.ok) {
          // If the API request is successful, remove the patient from the list
          setPatients(patients.filter((patient) => patient.id !== patientId));
        } else {
          console.error("Failed to delete patient");
        }
      })
      .catch((error) => {
        console.error("Error deleting patient:", error);
      });
  };

  const handleEditSubmit = (editedPatient) => {
    // Send a PUT request to update the patient data
    fetch(`${apiUrl}/${editedPatient.id}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(editedPatient),
    })
      .then((response) => response.json())
      .then((updatedPatient) => {
        // Update the patients state with the edited patient
        setPatients(
          patients.map((patient) =>
            patient.id === updatedPatient.id ? updatedPatient : patient
          )
        );
        // Clear the editPatient state
        setEditPatient(null);
        setShowForm(false); // Hide the edit form
      })
      .catch((error) => {
        console.error("Error updating patient:", error);
      });
  };

  const handleEdit = (patientId) => {
    // Make an API request to fetch the patient data by their ID for editing
    fetch(`${apiUrl}/${patientId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((patient) => {
        // Set the patient to edit in the state
        setEditPatient(patient);
        // Show the form for editing
        setShowForm(true);
      })
      .catch((error) => {
        console.error("Error fetching patient data for edit:", error);
      });
  };

  return (
    <div>
      <div className="add-form">
        <button className="btn btn-primary" onClick={() => setShowForm(true)}>
          Add Patient
        </button>
        {showForm && (
          <EditPatientForm
            patient={editPatient}
            handleFormSubmit={handleEditSubmit}
            handleClose={() => setShowForm(false)}
          />
        )}
      </div>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {patients.map((patient) => (
            <tr key={patient.id}>
              <td>{patient.name}</td>
              <td>{patient.email}</td>
              <td>{patient.mobile}</td>
              <td>
                <button className="btn btn-warning" onClick={() => handleEdit(patient.id)}>
                  Edit
                </button>
                <button className="btn btn-danger" onClick={() => handleDelete(patient.id)}>
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function EditPatientForm({ patient, handleFormSubmit, handleClose }) {
  const [editedPatient, setEditedPatient] = useState(patient);

  const handleSaveChanges = () => {
    handleFormSubmit(editedPatient);
  };

  return (
    <Form>
      <Form.Group controlId="formBasicName">
        <Form.Label>Name</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter name"
          value={editedPatient.name}
          onChange={(e) =>
            setEditedPatient({ ...editedPatient, name: e.target.value })
          }
        />
      </Form.Group>
      <Form.Group controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control
          type="email"
          placeholder="Enter email"
          value={editedPatient.email}
          onChange={(e) =>
            setEditedPatient({ ...editedPatient, email: e.target.value })
          }
        />
      </Form.Group>
      <Form.Group controlId="formBasicMobile">
        <Form.Label>Mobile</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter mobile"
          value={editedPatient.mobile}
          onChange={(e) =>
            setEditedPatient({ ...editedPatient, mobile: e.target.value })
          }
        />
      </Form.Group>
      <Button variant="primary" onClick={handleSaveChanges}>
        Save Changes
      </Button>
      <Button variant="danger" onClick={handleClose}>
        Cancel
      </Button>
    </Form>
  );
}
