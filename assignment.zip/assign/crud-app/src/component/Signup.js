import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Form, Button, Modal } from "react-bootstrap";
import Home from "./Home";

export default function SignUp() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    mobileNumber: "",
  });
  const navigate = useNavigate();
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});
  const [errorMessage, setErrorMessage] = useState("");

  const handleSuccessClose = () => {
    setShowSuccess(false);
    navigate("/signin");
  };

  const handleCloseError = () => {
    setShowError(false);
  };

  const handleFieldChange = (field, value) => {
    setForm({ ...form, [field]: value });

    // Clear error message for the field when the user starts typing
    if (fieldErrors[field]) {
      const errors = { ...fieldErrors };
      delete errors[field];
      setFieldErrors(errors);
    }
  };

  const validateEmail = (email) => {
    // Regular expression to check for a valid email format
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    return emailRegex.test(email);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Check if any field is empty
    const emptyFields = Object.keys(form).filter((key) => !form[key]);
    if (emptyFields.length > 0) {
      const errors = {};
      emptyFields.forEach((field) => {
        errors[field] = "This field is required";
      });
      setFieldErrors(errors);
      return;
    }

    if (!validateEmail(form.email)) {
      setFieldErrors({ ...fieldErrors, email: "Email is not in the correct format" });
      return;
    }

    const response = await fetch("http://localhost:5000/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });

    if (response.status === 200) {
      setShowSuccess(true);
    } else {
      const data = await response.json();
      setErrorMessage(data.message);
      setShowError(true);
    }
  };

  return (
    <div className="form_crud" style={{ padding: "100px" }}>
      <Home />
      <Form className="signup-form" onSubmit={handleSubmit}>
        <Form.Group controlId="formBasicName">
          <Form.Label>Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter name"
            value={form.name}
            onChange={(e) => handleFieldChange("name", e.target.value)}
          />
          {fieldErrors.name && <div className="error">{fieldErrors.name}</div>}
        </Form.Group>

        <Form.Group controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            value={form.email}
            onChange={(e) => handleFieldChange("email", e.target.value)}
          />
          {fieldErrors.email && <div className="error">{fieldErrors.email}</div>}
        </Form.Group>

        <Form.Group controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={(e) => handleFieldChange("password", e.target.value)}
          />
          {fieldErrors.password && <div className="error">{fieldErrors.password}</div>}
        </Form.Group>

        <Form.Group controlId="forMobile">
          <Form.Label>Mobile Number</Form.Label>
          <Form.Control
            type="number"
            placeholder="Mobile Number"
            value={form.mobileNumber}
            onChange={(e) => handleFieldChange("mobileNumber", e.target.value)}
          />
          {fieldErrors.mobileNumber && <div className="error">{fieldErrors.mobileNumber}</div>}
        </Form.Group>

        <Button variant="primary" type="submit" className="btn mt-2">
          Sign Up
        </Button>
      </Form>

      <Modal show={showSuccess} onHide={handleSuccessClose}>
        <Modal.Header closeButton>
          <Modal.Title>Success</Modal.Title>
        </Modal.Header>
        <Modal.Body>Sign-up was successful. Would you like to sign in now?</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleSuccessClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSuccessClose}>
            Sign In
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal show={showError} onHide={handleCloseError}>
        <Modal.Header closeButton>
          <Modal.Title>Error</Modal.Title>
        </Modal.Header>
        <Modal.Body>{errorMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseError}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
