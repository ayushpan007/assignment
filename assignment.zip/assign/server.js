const path = require("path");
const cors = require("cors");
const express = require("express");
const bodyParser = require("body-parser");
const { PORT } = require("./config");
const app = express();
const mongoose = require("mongoose");
const server = app.listen(PORT);
try {
  app.use(cors());
  app.use(express.json());
  console.log(`server listening on port ${PORT}`);
  const routes = require("./routes");

  app.use(bodyParser.urlencoded({ extended: false }));
  //connect to local
  mongoose
    .connect("mongodb://localhost:27017/assignment", {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    })
    .then(() => {
      console.log("Connected to Database...");
    })
    .catch((err) => {
      console.error("Could not connect to Database...");
      console.error(err);
    });

  app.use("/", routes);
} catch (err) {
  console.log(err);
  server.close();
}
