const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "./../.env") });
const Patient = require("../modals/patient");
const { handleError, sendres } = require("../utils/helper");
const axios = require("axios");
const { Client } = require("fhir-kit-client");

//const fhirClient = new Client({ baseUrl: "http://localhost:8080/fhir" });



//using the api

const getAllPatients = async (req, res) => {
  try {
    const allPatients = await axios.get(`http://hapi.fhir.org/baseR4/Patient`);
    if (allPatients.status === 200) {
      return sendres(200, allPatients.data, res);
    }
    return sendres(404, { message: "No list of patients found" }, res);
  } catch (err) {
    handleError(err, res);
  }
};

const addPatients = async (req, res) => {
  try {
    const patientData = req.body;
    if (!patientData) {
      return sendres(400, { message: "Data must be provided" }, res);
    }

    const savedPatientData = await axios.post(
      "http://hapi.fhir.org/baseR4/Patient",
      patientData
    );

    if (savedPatientData.status === 201) {
      const newPatient = new Patient({
        resourceType: savedPatientData.data.resourceType,
        patientId: savedPatientData.data.id,
        name: savedPatientData.data.name,
        gender: savedPatientData.data.gender,
        birthDate: savedPatientData.data.birthDate,
        telecom: savedPatientData.data.telecom,
        address: savedPatientData.data.address,
      });

      const savedPatient = await newPatient.save();
      return sendres(201, { savedPatient }, res);
    }
  } catch (err) {
    handleError(err, res);
  }
};

const getPatientById = async (req, res) => {
  try {
    patientId = req.params.patientId;
    if (!patientId) {
      return sendres(400, { message: "Patient Id is required" });
    }
    const patientData = await axios.get(
      `http://hapi.fhir.org/baseR4/Patient/${patientId}`
    );
    if (patientData.status === 200) {
      if (patientData.data) {
        return sendres(200, patientData.data, res);
      }
      return sendres(
        400,
        { message: `No Patient of this ${patientId} found` },
        res
      );
    }
  } catch (err) {
    handleError(err, res);
  }
};

const editPatient = async (req, res) => {
  try {
    const patientId = req.params.patientId;
    const updatedPatientData = req.body;
    const patient = await Patient.findOne({ patientId });

    if (!patient) {
      return sendres(404, { message: "Patient not found" }, res);
    }
    patient.name = updatedPatientData.name || patient.name;
    patient.gender = updatedPatientData.gender || patient.gender;
    patient.birthDate = updatedPatientData.birthDate || patient.birthDate;
    patient.telecom = updatedPatientData.telecom || patient.telecom;
    patient.address = updatedPatientData.address || patient.address;
    const updatedPatient = await patient.save();

    return sendres(200, { updatedPatient }, res);
  } catch (err) {
    handleError(err, res);
  }
};

const removePatient = async (req, res) => {
  try {
    const patientId = req.params.patientId;
    if (!patientId) {
      return sendres(400, { message: "Patient Id is required" });
    }
    const response = await axios.delete(
      `http://hapi.fhir.org/baseR4/Patient${patientId}`
    );
    if (response.status == 200) {
      const isdelted = await Patient.deleteOne({ patientId });
      if (isdelted) {
        return sendres(200, { message: "sucessfully deleted" }, res);
      }
      return sendres(
        400,
        { message: "Error in deleting patient from database" },
        res
      );
    }
    return sendres(
      400,
      { message: "Not able to delete patient from the fhir" },
      res
    );
  } catch (err) {
    handleError(err, res);
  }
};

//using the library
// const addPatients = async (req, res) => {
//   try {
//     if (
//       !req.body ||
//       !req.body.resourceType ||
//       req.body.resourceType !== "Patient"
//     ) {
//       return sendres(400, { message: "Invalid FHIR data" }, res);
//     }

//     const response = await fhirClient.create({
//       resourceType: "Patient",
//       body: req.body,
//     });
//     return sendres(200, response.data, res);
//   } catch (err) {
//     handleError(err, res);
//   }
// };

// const getPatientById = async (req, res) => {
//   try {
//     const patientId = req.params.patientId;
//     if (!patientId) {
//       return sendres(400, { message: "Patient Id is required" });
//     }
//     const response = await fhirClient.search({
//       resourceType: "Patient",
//       searchParams: { patientId },
//     });
//     return sendres(200, response.data.entry, res);
//   } catch (err) {
//     handleError(err, res);
//   }
// };

// const editPatient = async (req, res) => {
//   try {
//     const id = req.params.patientId;
//     if (!Id) {
//       return sendres(400, { message: "Patient Id is required" });
//     }
//     if (
//       !req.body ||
//       !req.body.resourceType ||
//       req.body.resourceType !== "Patient"
//     ) {
//       return sendres(400, { message: "Invalid FHIR data" }, res);
//     }

//     const response = await fhirClient.update({
//       resourceType: "Patient",
//       id,
//       body: req.body,
//     });

//     return sendres(200, response.data.entry, res);
//   } catch (err) {
//     handleError(err, res);
//   }
// };

// const removePatient = async (req, res) => {
//   try {
//     const id = req.params.patientId;
//     if (!Id) {
//       return sendres(400, { message: "Patient Id is required" });
//     }
//     const response = await fhirClient.delete({
//       resourceType: "Patient",
//     });

//     sendres(
//       200,
//       {
//         message: `Patient record with ID ${req.params.id} has been deleted`,
//       },
//       res
//     );
//   } catch (err) {
//     handleError(err, res);
//   }
// };

module.exports = {
  getAllPatients,
  addPatients,
  getPatientById,
  editPatient,
  removePatient,
};
