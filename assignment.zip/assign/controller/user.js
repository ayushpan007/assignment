const User = require("../modals/user");
const { handleError, sendres } = require("../utils/helper");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "./../.env") });

const signup = async (req, res) => {
  try {
    const { name, email, password, mobileNumber } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return sendres(
        400,
        { message: "The user already exist please signin" },
        res
      );
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({
      name,
      email,
      password: hashedPassword,
      mobileNumber,
    });
    await newUser.save();

    const payload = {
      email,
      name,
    };

    sendres(
      200,
      {
        message: "suceessfully registered",
      },
      res
    );
  } catch (err) {
    handleError(err, res);
  }
};

const signin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const checkIfExisting = await User.findOne({ email });
    if (checkIfExisting) {
      const isPasswordSame = bcrypt.compareSync(
        password,
        checkIfExisting._doc.password
      );
      if (isPasswordSame) {
        const payload = {
          email,
          userId: checkIfExisting._id,
        };
        const token = jwt.sign(payload, process.env.secret_key, {
          expiresIn: "1d",
        });
        return sendres(200, { message: "Sucessfully Logged In", token }, res);
      }
      return sendres(400, { message: "Incorrect Password" }, res);
    }
    return sendres(400, { message: "Not existing User, Please signin" }, res);
  } catch (err) {
    handleError(err, res);
  }
};

module.exports = {
  signup,
  signin,
};
