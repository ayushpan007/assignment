module.exports = Object.freeze({
  STAGING_DEV_ENV: "STAGING",
  LOCAL_DEV_ENV: "LOCAL",
  PROD_DEV_ENV: "PROD",
});
