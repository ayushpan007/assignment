# FHIR-Based Healthcare Data Management System

This project is a healthcare data management system that utilizes the Fast Healthcare Interoperability Resources (FHIR) standard for exchanging healthcare information electronically. It provides features for managing patient data and integrates with MongoDB as the database. The project consists of both a backend API and a frontend application.

## Table of Contents
- [Installation](#installation)
- [Usage](#usage)
- [Environment Configuration](#environment-configuration)
- [Backend](#backend)
- [Frontend](#frontend)
- [Contributing](#contributing)
- [License](#license)

## Installation

To run this project, you'll need to set up the backend and the frontend separately. Start by installing the necessary dependencies.

### Backend

Navigate to the `backend` directory and run:

npm install
**Frontend**
Move to the crud-app directory and run:
npm install
To run the frontend application, use the following command in the crud-app directory:
npm start
The frontend application will be accessible at http://localhost:3000.
**Backend**
To start the backend server, use the following command 
npm start
The backend application will be accessible at http://localhost:5000.

**Environment Configuration**

Create a .env file in the backend directory to set up your environment variables. Here's an example of what your .env file should contain:
env
secret_key=ayushayushayushayushayushayushayush
